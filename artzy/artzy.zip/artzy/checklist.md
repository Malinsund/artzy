### TO DO ###

- [] Mappstruktur
- [] Endpoints - User, övergripande struktur
- [] Endpoints - Posts, övergripande struktur
- [] Middlewares - user
- [] Middlewares - posts
- [] Schema+model - user
- [] Schema + model - Posts
- [] Funktioner
- []