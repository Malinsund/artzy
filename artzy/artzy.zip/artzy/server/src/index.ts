// DEN HÄR FILEN MÅSTE REDIGERAS AV DIG SOM STUDENT
// SÅ ATT TESTERNA KAN LÄSA DIN KOD KORREKT.

// ÄNDRA INTE FÖLJANDE KOD!
export * from "./app";
// ÄNDRA FÖLJANDE KOD SÅ ATT DINA MODELLER OCH TYPER EXPORTERAS KORREKT:
export { Post, PostModel } from "../resources/posts/posts-model";
export { User, UserModel } from "../resources/users/users-model";
// export * from "./server";
